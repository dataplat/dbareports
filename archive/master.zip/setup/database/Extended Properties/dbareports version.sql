EXEC sp_addextendedproperty N'dbareports version', N'0.0.4', NULL, NULL, NULL, NULL, NULL, NULL
GO
