EXEC sp_addextendedproperty N'dbareports logfilefolder', N'', NULL, NULL, NULL, NULL, NULL, NULL
GO
